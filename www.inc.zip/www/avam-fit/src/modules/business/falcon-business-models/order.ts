export interface Order {
    orderId : string;
    status: string;
}