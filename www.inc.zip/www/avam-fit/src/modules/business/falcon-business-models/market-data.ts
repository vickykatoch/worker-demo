export interface MarketData {
    RecordId : string;
    v: boolean;
}