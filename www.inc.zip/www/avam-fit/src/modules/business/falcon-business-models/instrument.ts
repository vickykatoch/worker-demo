export interface Instrument {
    marketDataId : string;
    market: string;
    alias: string;
    description: string;
    tickSize: number;
    
}

export interface StrategyInstrument extends Instrument {

}