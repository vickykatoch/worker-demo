import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import * as components from './components';
import { GridsterPrototypeService } from './components/gridster-prototype/gridster-prototype.service';


const compList = [
  components.GridsterComponent,
  components.GridsterItemComponent,
  components.GridsterItemPrototypeDirective
];


@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    ...compList
  ], exports: [
    ...compList
  ], providers: [
    GridsterPrototypeService
  ]
})
export class FalconGridsterModule { }
