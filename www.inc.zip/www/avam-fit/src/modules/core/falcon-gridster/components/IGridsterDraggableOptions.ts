export interface IGridsterDraggableOptions {
    handlerClass?: string;
    zIndex?: number;
    scroll?: boolean;
    scrollEdge?: number;
    containment?: string;
}
