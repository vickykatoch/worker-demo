import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// import { ReactiveFormsModule } from '@angular/forms';
import { FalconChromeComponent } from './falcon-chrome/falcon-chrome.component';
import { WindowTitleService } from './services';


@NgModule({
  imports: [
    CommonModule,
  ],
  providers : [
    WindowTitleService
  ],
  exports : [
    FalconChromeComponent
  ],
  declarations: [FalconChromeComponent]
})
export class FalconWindowChromeModule { }
