import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject  } from 'rxjs/BehaviorSubject';

@Injectable()
export class WindowTitleService {
  // private titleNotifier = new BehaviorSubject<string>('Window');
  // title$ = this.titleNotifier.asObservable();

  constructor() { }

  setTitle(title: string) {
    // this.titleNotifier.next(title);
  }



}
