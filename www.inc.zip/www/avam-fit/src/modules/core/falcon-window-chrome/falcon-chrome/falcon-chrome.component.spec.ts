import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FalconChromeComponent } from './falcon-chrome.component';

describe('FalconChromeComponent', () => {
  let component: FalconChromeComponent;
  let fixture: ComponentFixture<FalconChromeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FalconChromeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FalconChromeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
