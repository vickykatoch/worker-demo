import { Component, OnInit, Input } from '@angular/core';


@Component({
  selector: 'falcon-chrome',
  templateUrl: './falcon-chrome.component.html',
  styleUrls: ['./falcon-chrome.component.scss']
})
export class FalconChromeComponent implements OnInit {

  @Input() title : string = 'Window';
  @Input() showDropdownMenu = true;
  @Input() showMinimize = true;
  @Input() showMaximize = true;
  @Input() showClose = true;
  @Input() showFooter = true;

  constructor() { 

  }

  ngOnInit() {
  }

}
