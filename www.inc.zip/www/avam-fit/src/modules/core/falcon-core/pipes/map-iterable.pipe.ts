import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'mapIterable'
})
export class MapIterablePipe implements PipeTransform {

  transform(value: any, args?: any): any {
    if(value instanceof Map) {
      const values = [];
      value.forEach(val=>values.push(val));
      return values;
    }
    return value;
  }

}
