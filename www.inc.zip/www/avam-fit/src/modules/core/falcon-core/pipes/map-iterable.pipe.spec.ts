import { MapIterablePipe } from './map-iterable.pipe';

describe('MapIterablePipe', () => {
  it('create an instance', () => {
    const pipe = new MapIterablePipe();
    expect(pipe).toBeTruthy();
  });
});
