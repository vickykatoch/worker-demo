import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MapIterablePipe } from './pipes/map-iterable.pipe';

@NgModule({
  imports: [
    CommonModule
  ],
  exports : [
    MapIterablePipe
  ],
  declarations: [
    MapIterablePipe
  ]
})
export class FalconCoreModule { }
