import { Component, OnInit, ChangeDetectionStrategy, Input } from '@angular/core';

@Component({
    selector: 'jett-price-column',
    template: `
        <div class="col">{{price}}</div>
  `,
    styleUrls: ['./price-column.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class PriceColumnComponent implements OnInit {
    @Input() price : number;

    constructor() { }

    ngOnInit() {
    }

}
