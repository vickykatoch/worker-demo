import { Component } from '@angular/core';

@Component({
  selector: 'fit-ml-host',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'Market Ladder';
}
