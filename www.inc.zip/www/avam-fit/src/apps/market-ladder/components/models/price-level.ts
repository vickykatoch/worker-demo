import { Order } from "$falcon-business-models";

export interface PriceLevel {
    myOrders? : Order[];
    myBid? : number;
    price: number;
    myAsk? : number;
    volume?: number;
}