import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'jett-ladder-ohlc',
  templateUrl: './ladder-ohlc.component.html',
  styleUrls: ['./ladder-ohlc.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class LadderOhlcComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
