import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LadderOhlcComponent } from './ladder-ohlc.component';

describe('LadderOhlcComponent', () => {
  let component: LadderOhlcComponent;
  let fixture: ComponentFixture<LadderOhlcComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LadderOhlcComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LadderOhlcComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
