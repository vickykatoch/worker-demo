import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'jett-ladder-instrument-info',
  templateUrl: './ladder-instrument-info.component.html',
  styleUrls: ['./ladder-instrument-info.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class LadderInstrumentInfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
