import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LadderInputPadComponent } from './ladder-input-pad.component';

describe('LadderInputPadComponent', () => {
  let component: LadderInputPadComponent;
  let fixture: ComponentFixture<LadderInputPadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LadderInputPadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LadderInputPadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
