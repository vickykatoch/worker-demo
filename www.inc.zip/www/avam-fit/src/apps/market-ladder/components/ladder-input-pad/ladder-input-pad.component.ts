import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'jett-ladder-input-pad',
  templateUrl: './ladder-input-pad.component.html',
  styleUrls: ['./ladder-input-pad.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class LadderInputPadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
