import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MultiLadderViewComponent } from './multi-ladder-view.component';

describe('MultiLadderViewComponent', () => {
  let component: MultiLadderViewComponent;
  let fixture: ComponentFixture<MultiLadderViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MultiLadderViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MultiLadderViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
