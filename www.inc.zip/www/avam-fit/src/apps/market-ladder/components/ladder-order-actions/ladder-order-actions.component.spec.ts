import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LadderOrderActionsComponent } from './ladder-order-actions.component';

describe('LadderOrderActionsComponent', () => {
  let component: LadderOrderActionsComponent;
  let fixture: ComponentFixture<LadderOrderActionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LadderOrderActionsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LadderOrderActionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
