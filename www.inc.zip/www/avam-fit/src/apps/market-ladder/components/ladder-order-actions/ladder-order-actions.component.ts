import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'jett-ladder-order-actions',
  templateUrl: './ladder-order-actions.component.html',
  styleUrls: ['./ladder-order-actions.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class LadderOrderActionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
