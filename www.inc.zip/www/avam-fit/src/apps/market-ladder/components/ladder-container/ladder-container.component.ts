import { Component, OnInit } from '@angular/core';
import { Instrument } from '$falcon-business-models';

@Component({
  selector: 'jett-ladder-container',
  templateUrl: './ladder-container.component.html',
  styleUrls: ['./ladder-container.component.scss']
})
export class LadderContainerComponent implements OnInit {
  private instrument: Instrument;

  constructor() { }

  ngOnInit() {
    this.instrument = {
      marketDataId: '2_YEAR.UROX',
      market: 'SOR-CASH',
      alias: '2_YEAR',
      description: '2 YEAR',
      tickSize: 1
    };
  }

}
