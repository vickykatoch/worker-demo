import {
  Component,
  OnInit,
  ChangeDetectionStrategy,
  Input,
  OnChanges,
  SimpleChanges,
  SimpleChange
} from '@angular/core';
import { Instrument, Order, StrategyInstrument, MarketData } from '$falcon-business-models';
import { PriceLevel } from '../models/price-level';
import { PriceLevelService } from './services/price-level.service';
import { } from '@angular/core/src/metadata/lifecycle_hooks';



const PRICE_LEVEL_COUNT = 20;
const DEFAULT_MID_PRICE = 100;


@Component({
  selector: 'jett-ladder-grid',
  templateUrl: './ladder-grid.component.html',
  styleUrls: ['./ladder-grid.component.scss'],
  providers: [PriceLevelService],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class LadderGridComponent implements OnInit, OnChanges {
  @Input() instrument: Instrument;
  marketData: MarketData;
  myOrders: Order[] = [];
  priceLevels = new Map<number, PriceLevel>();

  constructor(private priceLevelService: PriceLevelService) { }

  ngOnInit() {

  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes['instrument']) {
      console.log(changes);
      const changedInstrument = <Instrument>(<SimpleChange>changes['instrument']).currentValue;
      
      if (changedInstrument) {
        this.priceLevels = this.priceLevelService
          .generatePriceLevels(PRICE_LEVEL_COUNT, DEFAULT_MID_PRICE, changedInstrument.tickSize);
      } else {
        this.priceLevels.clear();
      }
    }
  }


}
