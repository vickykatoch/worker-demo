import { Injectable } from '@angular/core';
import { PriceLevel } from '../../models/price-level';

@Injectable()
export class PriceLevelService {

  constructor() { }

  generatePriceLevels(levelCount: number, midPrice: number, tickSize: number) : Map<number, PriceLevel> {
    const priceLevelMap = new Map<number, PriceLevel>();
    let price = (midPrice + tickSize*(Math.floor(levelCount/2)));
    priceLevelMap.set(price,{ price });
    for(let i = 1;i<= levelCount;i++) {
      price -= tickSize;
      priceLevelMap.set(price,{ price});
    }
    return priceLevelMap;
  }
}
