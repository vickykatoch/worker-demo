import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LadderGridComponent } from './ladder-grid.component';

describe('LadderGridComponent', () => {
  let component: LadderGridComponent;
  let fixture: ComponentFixture<LadderGridComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LadderGridComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LadderGridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
