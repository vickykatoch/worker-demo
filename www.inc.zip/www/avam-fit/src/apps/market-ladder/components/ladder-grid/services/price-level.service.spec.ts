import { TestBed, inject } from '@angular/core/testing';

import { PriceLevelService } from './price-level.service';

describe('PriceLevelService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PriceLevelService]
    });
  });

  it('should be created', inject([PriceLevelService], (service: PriceLevelService) => {
    expect(service).toBeTruthy();
  }));
});
