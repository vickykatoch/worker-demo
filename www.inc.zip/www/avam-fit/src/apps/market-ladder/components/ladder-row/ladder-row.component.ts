import {
  Component,
  OnInit,
  ChangeDetectionStrategy,
  Input
} from '@angular/core';
import { PriceLevel } from '../models/price-level';

@Component({
  selector: 'jett-ladder-row',
  template: `
    <div class="row">
      <jett-price-column [price]="priceLevel.price"></jett-price-column> 
    </div>
  `,
  styleUrls: ['./ladder-row.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class LadderRowComponent implements OnInit {
  @Input() priceLevel: PriceLevel;


  constructor() { }

  ngOnInit() {
  }

}
