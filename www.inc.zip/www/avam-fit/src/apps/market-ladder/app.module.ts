import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import * as components from './components';
import { FalconWindowChromeModule } from '$falcon-window-chrome';
import { FalconCoreModule } from '$falcon-core';
import { FalconGridsterModule } from '$falcon-gridster';


const componentList = [
  components.PriceColumnComponent,
  components.LadderContainerComponent,
  components.LadderGridComponent,
  components.LadderInputPadComponent,
  components.LadderInstrumentInfoComponent,
  components.LadderOhlcComponent,
  components.LadderOrderActionsComponent,
  components.LadderRowComponent,
  components.MultiLadderViewComponent,
  components.AppComponent
];



@NgModule({
  declarations: [
    ...componentList
  ],
  imports: [
    BrowserModule,
    FalconCoreModule,
    FalconGridsterModule,
    FalconWindowChromeModule
  ],
  providers: [],
  bootstrap: [components.AppComponent]
})
export class AppModule { }
